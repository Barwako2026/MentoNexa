"use strict";

// MentoNexa demonstration application.
// Requests are saved only in this browser using localStorage.

const STORAGE_KEY = "mentonexaRequests";
const DEMO_ADMIN_PASSWORD = "Admin@123"; // Demo only. Not secure for production.

const mentorForm = document.getElementById("mentorForm");
const selectedMentorInput = document.getElementById("selectedMentor");
const selectedMentorText = document.getElementById("selectedMentorText");
const formMessage = document.getElementById("formMessage");
const adminLoginForm = document.getElementById("adminLoginForm");
const adminLoginSection = document.getElementById("adminLoginSection");
const adminDashboard = document.getElementById("adminDashboard");
const loginMessage = document.getElementById("loginMessage");
const requestsTableBody = document.getElementById("requestsTableBody");

function getRequests() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(stored) ? stored : [];
  } catch (error) {
    console.error("Could not read saved requests:", error);
    return [];
  }
}

function saveRequests(requests) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(requests));
    return true;
  } catch (error) {
    console.error("Could not save requests:", error);
    return false;
  }
}

function selectMentor(mentorName) {
  selectedMentorInput.value = mentorName;
  selectedMentorText.textContent = `Selected mentor: ${mentorName}`;
  formMessage.textContent = "";
  document.getElementById("request").scrollIntoView({ behavior: "smooth" });
}

document.querySelectorAll(".mentor-btn").forEach((button) => {
  button.addEventListener("click", () => selectMentor(button.dataset.mentor));
});

mentorForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!selectedMentorInput.value) {
    formMessage.textContent = "Please choose a mentor before submitting your request.";
    formMessage.style.color = "#b42318";
    document.getElementById("mentors").scrollIntoView({ behavior: "smooth" });
    return;
  }

  const request = {
    id: (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()),
    name: document.getElementById("name").value.trim(),
    email: document.getElementById("email").value.trim(),
    profession: document.getElementById("profession").value,
    experience: document.getElementById("experience").value.trim(),
    message: document.getElementById("message").value.trim(),
    mentor: selectedMentorInput.value,
    preferredDate: document.getElementById("preferredDate").value || "Not specified",
    date: new Date().toLocaleString(),
    status: "Pending"
  };

  const requests = getRequests();
  requests.push(request);

  if (!saveRequests(requests)) {
    formMessage.textContent = "Your request could not be saved in this browser. Please check your browser storage settings.";
    formMessage.style.color = "#b42318";
    return;
  }

  formMessage.textContent = `Thank you! Your demonstration request for ${request.mentor} has been submitted.`;
  formMessage.style.color = "#16834b";
  mentorForm.reset();
  selectedMentorInput.value = "";
  selectedMentorText.textContent = "No mentor selected yet. Choose a mentor above to get started.";
});

function createCell(text) {
  const cell = document.createElement("td");
  cell.textContent = text || "Not provided";
  return cell;
}

function createActionButton(label, className, onClick) {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = label;
  button.className = className;
  button.addEventListener("click", onClick);
  return button;
}

function updateRequestStatus(requestId, newStatus) {
  const requests = getRequests();
  const target = requests.find((request) => request.id === requestId);
  if (!target) return;
  target.status = newStatus;
  saveRequests(requests);
  renderDashboard();
}

function deleteRequest(requestId) {
  const confirmed = window.confirm("Delete this mentorship request? This cannot be undone.");
  if (!confirmed) return;
  const requests = getRequests().filter((request) => request.id !== requestId);
  saveRequests(requests);
  renderDashboard();
}

function renderDashboard() {
  if (!requestsTableBody) return;

  const requests = getRequests();
  const pending = requests.filter((request) => request.status === "Pending").length;
  const approved = requests.filter((request) => request.status === "Approved").length;
  const rejected = requests.filter((request) => request.status === "Rejected").length;

  document.getElementById("totalRequests").textContent = String(requests.length);
  document.getElementById("pendingRequests").textContent = String(pending);
  document.getElementById("approvedRequests").textContent = String(approved);
  document.getElementById("rejectedRequests").textContent = String(rejected);

  requestsTableBody.replaceChildren();
  document.getElementById("emptyRequestsMessage").hidden = requests.length > 0;

  requests.forEach((request) => {
    const row = document.createElement("tr");
    row.appendChild(createCell(request.name));
    row.appendChild(createCell(request.email));
    row.appendChild(createCell(request.profession));
    row.appendChild(createCell(request.experience));
    row.appendChild(createCell(request.mentor));
    row.appendChild(createCell(request.preferredDate || "Not specified"));

    const statusCell = document.createElement("td");
    const status = document.createElement("span");
    const statusValue = request.status || "Pending";
    status.className = `status status-${statusValue.toLowerCase()}`;
    status.textContent = statusValue;
    statusCell.appendChild(status);
    row.appendChild(statusCell);

    const actionsCell = document.createElement("td");
    actionsCell.appendChild(createActionButton("Approve", "approve-button", () => updateRequestStatus(request.id, "Approved")));
    actionsCell.appendChild(createActionButton("Reject", "reject-button", () => updateRequestStatus(request.id, "Rejected")));
    actionsCell.appendChild(createActionButton("Delete", "delete-button", () => deleteRequest(request.id)));
    row.appendChild(actionsCell);

    requestsTableBody.appendChild(row);
  });
}

document.getElementById("refreshRequests").addEventListener("click", renderDashboard);

document.getElementById("clearAllRequests").addEventListener("click", () => {
  const confirmed = window.confirm("Delete ALL demonstration requests saved in this browser?");
  if (!confirmed) return;
  saveRequests([]);
  renderDashboard();
});

adminLoginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const enteredPassword = document.getElementById("adminPassword").value;

  if (enteredPassword === DEMO_ADMIN_PASSWORD) {
    adminLoginSection.hidden = true;
    adminDashboard.hidden = false;
    loginMessage.textContent = "";
    adminLoginForm.reset();
    renderDashboard();
    adminDashboard.scrollIntoView({ behavior: "smooth" });
  } else {
    loginMessage.textContent = "Incorrect password. Please try again.";
    loginMessage.style.color = "#b42318";
  }
});

document.getElementById("logoutButton").addEventListener("click", () => {
  adminDashboard.hidden = true;
  adminLoginSection.hidden = false;
  document.getElementById("adminPassword").value = "";
  adminLoginSection.scrollIntoView({ behavior: "smooth" });
});

// Mobile navigation menu.
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
  });
});

MENTONEXA - REBUILT DEMONSTRATION WEBSITE

FILES
- index.html: website structure and content
- style.css: desktop and mobile styling
- script.js: mentor selection, request form, browser storage, and demo admin dashboard

HOW TO RUN
1. Keep all three files in the same folder.
2. Open the folder in Visual Studio Code.
3. Open index.html in a browser (or use the VS Code Live Server extension if installed).

DEMO ADMIN PASSWORD
Admin@123

IMPORTANT LIMITATIONS
- This is a front-end demonstration, not a production service.
- Mentorship requests are stored in localStorage in the current browser only.
- Records do not sync across browsers, users, or devices.
- The demo admin password is visible in script.js and is not secure.
- Mentor profiles and opportunity categories are sample demonstration content.
- Do not collect real sensitive personal information or use this login for real administration.
